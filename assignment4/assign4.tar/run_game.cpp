/*********************************************************************
 * ** Program Filename:run_game.cpp
 * ** Author:XiYuan Huang
 * ** Date:11/25/2018
 * ** Description:This is the main function of the game
 * ** Input:N/A
 * ** Output:N/A
 * *********************************************************************/
#include "game.h"

#include <iostream>

using namespace std;

int main()
{
	game player;
	player.user_menu();
	player.delete_vector();
return 0;
}

