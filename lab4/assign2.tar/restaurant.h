/*********************************************************************
 * ** Program Filename:restaurant.h
 * ** Author:XiYuan Huang
 * ** Date:10/22.2018
 * ** Description:This is the header of restaurant class.
 * ** Input:N/A
 * ** Output:N/A
 * *********************************************************************/
#ifndef RESTAURANT_H
#define RESTAURANT_H

#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>

#include "menu.h"

using namespace std;

struct employee {
 	string id;
 	string first_name;
 	string last_name;
 	string password;
};

struct hours {
 	string day;
 	string open_hour;
 	string close_hour;
};
struct orders {
	int order_num;
	string customer_first_name;
	string customer_last_name;
	string customer_cc;
	string delivery_address; 
	string customer_phone; 
	string pizza_name;
	string size; 
	string quantity; 
	
};

class Restaurant
{
	private:
 		Menu menu;
 		employee* employees;
 		hours* week;
		orders* order;
 		string name;
 		string phone;
 		string address;
		int num_employee;
		int num_day;
		int num_order;
		int user_id_location; 
 	public:
		Restaurant();
		~Restaurant();	
		Restaurant(const Restaurant& copy);
		Restaurant& operator = (const Restaurant &copy);
		void get_employee();
		void set_employee(ifstream&); 
		void print_employee();
		bool login(); 
		bool get_id();
		bool get_password();
		void employee_menu();
		bool employee_option_result(int);	
		void user_decision();
		void get_hours();
		void set_hours(ifstream&);
		void change_hour_file();
		int which_day();
		void change_hour();
		void get_orders();
		void set_orders(ifstream&);
		void view_order();
		void place_order();
		void add_order();	
		void remove_order(int);
		void put_order_in_file();
		void customer_menu();
		bool customer_option_result(int);
		void view_menu();
		void view_hours();
		void view_address();
		void view_phone();
		void menu_load_pizza();
		void remove_from_menu();
		//void add_to_menu();
		void load_data();//reads from files to correctly populate menu, employees, hours. 
};

#endif
