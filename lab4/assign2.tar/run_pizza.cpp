#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <string>

#include "restaurant.h"
using namespace std;

void customer_log_in(Restaurant &pizza)
{
	pizza.load_data();
	pizza.customer_menu();	
}
void employee_log_in(Restaurant &pizza)
{
	pizza.load_data();
	bool check_login = pizza.login();
	if(check_login == true) 
		pizza.employee_menu();
	
}

int main()
{
	bool input_valid = false;
	char user_id = ' ';
	Restaurant pizza;
	do{
		cout << "Welcome to Bytes Pizza! " << endl;
		cout << "Are you a customer (C) or employee (E) or would you like to quit (Q)?" << endl;
		cin >> user_id;	
		if(user_id == 'C' || user_id == 'c'){
			customer_log_in(pizza);
		}else if(user_id == 'E' || user_id == 'e'){
			employee_log_in(pizza);
		}else if(user_id == 'Q' || user_id == 'q'){
			cout << "you log out the system" << endl;
			input_valid = true;	
		}else{
			cout << "Please enter the correct input" << endl;
		}
	}while(input_valid == false);
	
	
	/*pizza.view_hours();
	pizza.view_address();
	pizza.view_phone();
	pizza.print_employee();
	pizza.view_menu();*/
}
