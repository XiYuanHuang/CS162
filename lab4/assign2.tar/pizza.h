/*********************************************************************
 * ** Program Filename:pizza.h
 * ** Author:XiYuan Huang
 * ** Date:10/22/2018
 * ** Description:This is the header file of pizza class
 * ** Input:N/A
 * ** Output:N/A
 * *********************************************************************/
#ifndef PIZZA_H
#define PIZZA_H

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>

using namespace std;

class Pizza {
 	private:
		string name;
		int small_cost;
 		int medium_cost;
 		int large_cost;
 		int num_ingredients;
 		string* ingredients;
 	
	public: 
		Pizza();
		~Pizza();
		Pizza(ifstream&);
		Pizza(const Pizza &copy);
		Pizza& operator = (const Pizza &copy);
		//void add_pizza();	
		string get_name();
		void set_name(string);
		int get_small_cost();
		void set_small_cost(int);
	 	int get_medium_cost();
		void set_medium_cost(int);
		int get_large_cost();
		void set_large_cost(int);
		int get_num_ingredients();
		void set_num_ingredients(int);
		string* get_ingredients();
		void set_ingredients(string*); 
};

#endif
