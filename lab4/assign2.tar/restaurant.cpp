/*********************************************************************
 * ** Program Filename:restaurant.cpp
 * ** Author:XiYuan Huang
 * ** Date:10/22/2018
 * ** Description:This file includes all the restaurant public functions
 * 	and connects with the menu and pizza class.
 * ** Input:N/A
 * ** Output:N/A
 * *********************************************************************/
#include "restaurant.h"

#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>

using namespace std;

Restaurant::Restaurant()
{
	employees = NULL;
	week = NULL;
	order = NULL;
 	name = " ";
	phone = " ";
	address = " ";		
}
Restaurant::~Restaurant()
{
	delete [] employees;
	employees = NULL;
	delete [] week;
	week = NULL;
	delete [] order;
	order = NULL;
}
Restaurant::Restaurant(const Restaurant& copy)
{
	num_employee = copy.num_employee;
	if(num_employee != 0){
		employees = new employee[num_employee];
		for(int i = 0; i < num_employee; i++){
			employees[i] = copy.employees[i];
		}
	}else{
		employees = NULL;
	}
	name = copy.name;
	phone = copy.phone;
	address = copy.address;
	num_day = copy.num_day;
	if(num_day != 0){
		week = new hours[num_day];
		for(int i = 0; i < 7; i++){
			week[i] = copy.week[i];
		}
	}else{
		week = NULL;
	}	
		menu = copy.menu;
}
Restaurant& Restaurant::operator = (const Restaurant &copy)
{
	if(week != NULL){
		delete [] week;
	}
	if(employees != NULL){
		delete [] employees;
	}
	name = copy.name;
	phone = copy.phone;
	address = copy.address;
	num_day = copy.num_day;
	if(num_day != 0){
		for(int i = 0; i < 7; i++){
			week[i] = copy.week[i];
		}
	}else{
		week = NULL;
	}
	num_employee = copy.num_employee;
	if(num_employee != 0){
		employees = new employee[num_employee];
		for(int i = 0; i < num_employee; i++){
			employees[i] = copy.employees[i];
		}
	}else{
		employees = NULL;
	}
	menu = copy.menu;
	return *this;
}
/*********************************************************************
 * ** Function:get_employee, set_employee, print_employee
 * ** Description:This three functions get an print the employee info
 * ** Parameters:N/A, reference of the file, N/A
 * ** Pre-Conditions:N/A
 * ** Post-Conditions:N/A
 * *********************************************************************/ 
void Restaurant::get_employee()
{
	ifstream employee_file;
	employee_file.open("employee.txt");
	if(employee_file.is_open()){
		cout << "employee_file is open" << endl;
		employee_file >> num_employee;
		employees = new employee[num_employee];
		set_employee(employee_file);
	}
	employee_file.close();
	
}
void Restaurant::set_employee(ifstream& employee_file)
{
	for(int i = 0; i < num_employee; i++){
			employee_file >> employees[i].id;
			employee_file >> employees[i].first_name;
			employee_file >> employees[i].last_name;
			employee_file >> employees[i].password;
	}
}
void Restaurant::print_employee()
{
	for(int i = 0; i < num_employee; i++){
		cout << employees[i].id << " ";
		cout << employees[i].first_name << " ";
		cout << employees[i].last_name << " ";
		cout << employees[i].password << endl;
	}
}
/********************************************************************/

void Restaurant::get_hours()
{
	ifstream hours_file;
	hours_file.open("restaurant_info.txt");
	if(hours_file.is_open()){
		cout << "hours_file is open" << endl;		
		getline(hours_file, name);
		getline(hours_file, phone);
		getline(hours_file, address);
		hours_file >> num_day;
		week = new hours[num_day];
		set_hours(hours_file);
	}
	hours_file.close();
}
void Restaurant::set_hours(ifstream& hours_file)
{
	for(int i = 0; i < num_day; i++){
		hours_file >> week[i].day;
		hours_file >> week[i].open_hour;
		hours_file >> week[i].close_hour;
	}
}
/*********************************************************************
 * ** Function:menu_load_pizza
 * ** Description:This function get the data from the add_to_menu funcion
 * 	and which already store in a menu object.
 * ** Parameters:N/A
 * ** Pre-Conditions:N/A
 * ** Post-Conditions:N/A
 * *********************************************************************/ 
void Restaurant::menu_load_pizza()
{
	ifstream pizza_file;
	pizza_file.open("menu.txt");
	int pizzaNum = 0;
	if(pizza_file.is_open()){
		cout << "pizza_file is open" << endl;
		pizza_file >> pizzaNum;
		while(!pizza_file.eof())
		{ 
			Pizza newPizza = Pizza(pizza_file);
			menu.add_to_menu(newPizza);
		}
	}
	pizza_file.close();
}
bool Restaurant::login()
{	
	bool valid_login = false, valid_id = false, valid_password = false;
	do{	
		valid_id = get_id();
		if(valid_id == false){
			break;
		}
		valid_password = get_password();
		if(valid_password == false){
			break;
		}
		if(valid_id == true && valid_password == true){
			valid_login = true;
		}
	}while(valid_login == false);
	if(valid_login == true){
	cout << "Welcome " << employees[user_id_location].first_name << employees[user_id_location].last_name << "!";
	cout << "What are you ganna do?" << endl;
		return true;
	}
	return false;
	
}
bool Restaurant::get_id()
{
	bool valid_id = false;
	do{
		cout << "Please provide your ID number: "<< " ";
		string user_id = " ";
		cin >> user_id;
		for(int i = 0; i < num_employee; i++){
			if(user_id == employees[i].id){
				user_id_location = i;
				return true;
			}
		}
		cout << "Please enter the corret ID" << endl;
		cout << "Do you want to quit Y/N" << endl;
		char quit = ' ';
		cin >> quit;		
		if(quit == 'Y' || quit == 'y')
			break;
	}while(valid_id == false);
	return false;
}
bool Restaurant::get_password()
{
	bool valid_password = false;
	do{
		cout << "Please provide your passoword" << endl;
		string user_password = " ";
		cin >> user_password;
		if(user_password == employees[user_id_location].password){
			return true;
		}
		cout << "Please enter the correct password" << endl;
		cout << "Do you want to quit Y/N" << endl;
		char quit = ' ';
		cin >> quit;
		if(quit == 'Y' || quit == 'y')
			break;
	}while(valid_password == false);
	return false;
}
void Restaurant::employee_menu()
{
	bool employee_prompt = false;
	int employee_option = 0;
	do{	
		cout << "1. change hours" << endl;
		cout << "2. View Orders" << endl;
		cout << "3. Remove Order" << endl;
		cout << "4. Add Item to Menu" << endl;
		cout << "5. Remove Item from Menu" << endl;
		cout << "6. View Menu" << endl;
		cout << "7. View Hours" << endl;
		cout << "8. View Address" << endl; 
		cout << "9. View Phone" << endl;
		cout << "10. Log out" << endl; 
		cin >> employee_option;
		cout << endl;
		employee_prompt = employee_option_result(employee_option);
	}while(employee_prompt == false);
}
bool Restaurant::employee_option_result(int employee_option)
{
	bool employee_prompt = false;
	switch(employee_option)
	{
		case 1:change_hour();
			break;
		case 2://get_orders();	
			view_order();
			break;
		case 3:user_decision();
			break;
		case 4://add_to_menu();
			break;
		case 5:remove_from_menu();
			break;
		case 6:view_menu();
			break;
		case 7:view_hours();
			break;
		case 8:view_address();
			break;
		case 9:view_phone();
			break;
		case 10:employee_prompt = true;
			break;
		default:
			cout << "You did not enter the correct input," << " ";
			cout << "plase try again" << endl;
	}
	return employee_prompt;
}
void Restaurant::change_hour()
{
	int day = 0, opening_time = 0, closing_time = 0;
	cout << "Which day would you like to change the hours for?" << endl;
	day = which_day();
	if(day > 0 && day < 8){
		cout << "What should the opening time be?" << endl;
		cin >> week[day - 1].open_hour;
		cout << "What should the closing time be?" << endl;
		cin >> week[day - 1].close_hour;
	}else{
		cout << "Please enter the correct input" << endl;
	}
	change_hour_file();
	//get_hours();
	view_hours();
}
void Restaurant::change_hour_file()
{
	ofstream hours_file;
	hours_file.open("restaurant_info.txt");
	if(hours_file.is_open()){
		hours_file << name << endl;
		hours_file << phone << endl;
		hours_file << address << endl;
		hours_file << num_day << endl;
		for(int i = 0; i < num_day; i++){
			hours_file << week[i].day << " ";
			hours_file << week[i].open_hour << " ";
			hours_file << week[i].close_hour << endl;
		}
	}
	hours_file.close();
}
int Restaurant::which_day()
{
	int day = 0;
	cout << "1.Sunday" << endl;
	cout << "2.Monday" << endl;
	cout << "3.Tuesday" << endl;
	cout << "4.Wednesday" << endl;
	cout << "5.Thursday" << endl;
	cout << "6.Friday" << endl;
	cout << "7.Saturday" << endl;
	cin >> day;
	return day;
}
void Restaurant::get_orders()
{
	ifstream orders_file;
	orders_file.open("orders.txt");
	if(orders_file.is_open()){
		cout << "orders_file is open" << endl;		
		orders_file >> num_order;
		order = new orders[num_order];
		set_orders(orders_file);
	}
	orders_file.close();
}
void Restaurant::set_orders(ifstream& orders_file)
{
	for(int i = 0; i < num_order; i++){
		orders_file >> order[i].order_num;
		orders_file >> order[i].customer_first_name;
		orders_file >> order[i].customer_last_name;
		orders_file >> order[i].customer_cc;
		orders_file >> order[i].delivery_address; 
		orders_file >> order[i].customer_phone; 
		orders_file >> order[i].pizza_name;
		orders_file >> order[i].size; 
		orders_file >> order[i].quantity;
		 
	}
}
void Restaurant::view_order()
{
	for(int i = 0; i < num_order; i++){
		order[i].order_num = i + 1;
		cout << order[i].order_num << " ";
		cout << order[i].customer_first_name << " ";
		cout << order[i].customer_last_name << " ";
		cout << order[i].customer_cc << " ";
		cout << order[i].delivery_address << " ";
		cout << order[i].customer_phone << " ";
		cout << order[i].pizza_name << " ";
		cout << order[i].size << " ";
		cout << order[i].quantity << endl;
	}
	//delete [] order;
	cout << endl;
}
void Restaurant::place_order()
{
	orders* new_order = new orders[num_order + 1];
	for(int i = 0; i < num_order; i++){
		//cout << "1.5" << endl;
		new_order[i].order_num = order[i].order_num;
		new_order[i].customer_first_name = order[i].customer_first_name;
		new_order[i].customer_last_name = order[i].customer_last_name;
		new_order[i].customer_cc = order[i].customer_cc;
		new_order[i].delivery_address = order[i].delivery_address;
		new_order[i].customer_phone = order[i].customer_phone;
		new_order[i].pizza_name = order[i].pizza_name;
		new_order[i].size = order[i].size;
		new_order[i].quantity = order[i].quantity;	
	}
	//cout << "2" << endl;
	delete [] order;
	//cout << "3" << endl;
	order = new struct orders[num_order + 1];
	//cout << "4" << endl;
	for(int j = 0; j < num_order + 1; j++){
		//cout << "5" << endl;
		order[j].order_num = new_order[j].order_num;
		order[j].customer_first_name = new_order[j].customer_first_name;
		order[j].customer_last_name = new_order[j].customer_last_name;
		order[j].customer_cc = new_order[j].customer_cc;
		order[j].delivery_address = new_order[j].delivery_address;
		order[j].customer_phone = new_order[j].customer_phone;
		order[j].pizza_name = new_order[j].pizza_name;
		order[j].size = new_order[j].size;
		order[j].quantity = new_order[j].quantity;
	}
	//cout << "6" << endl;
	delete [] new_order; 
	num_order++;
	//cout << "7" << endl;
	add_order(); 
	view_order();
	put_order_in_file();
}
void Restaurant::add_order()
{
	
	order[num_order-1].order_num = num_order;
	cout << "Your first name:" << " ";cin >> order[num_order-1].customer_first_name;
	cout << "Your last name:" << " ";cin>> order[num_order-1].customer_last_name;
	cout << "Your customer_cc:" << " ";cin >> order[num_order-1].customer_cc;
	cout << "Your deliver_address:" << " ";cin >> order[num_order-1].delivery_address;
	cout << "Your phone:" << " ";cin >> order[num_order-1].customer_phone;
	cout << "the name of pizza:" << " ";cin >> order[num_order-1].pizza_name;
	cout << "the size of pizza:" << " ";cin >> order[num_order-1].size;
	cout << "the quantity of pizza:" << " ";cin >> order[num_order-1].quantity; 
	
}
void Restaurant::put_order_in_file()
{
	ofstream order_file;
	order_file.open("orders.txt");
	if(order_file.is_open()){
		order_file << num_order << endl;
		for(int i=0; i < num_order; i++){
			order_file << order[i].order_num << " ";
			order_file << order[i].customer_first_name << " ";
			order_file << order[i].customer_last_name << " ";
			order_file << order[i].customer_cc << " ";
			order_file << order[i].delivery_address << " ";
			order_file << order[i].customer_phone << " ";
			order_file << order[i].pizza_name << " ";
			order_file << order[i].size << " ";
			order_file << order[i].quantity << endl;
		}
	}
	order_file.close();
}
void Restaurant::remove_order(int remove_order_num)
{
	for(int i = remove_order_num; i < num_order; i++){
		order[i-1] = order[i];
	}
	//delete [] order;
	num_order--;
	put_order_in_file();
	view_order();	
	//put_order_in_file();
}
void Restaurant::user_decision()
{
	int remove_order_num = 0;
	bool valid_input = false;
	do{
		cout << "please choose the order you want to remove" << endl;
		view_order();
		cin >> remove_order_num;
		if(remove_order_num > num_order || remove_order_num < 0){
			valid_input = false;
		}else{
			valid_input = true;
		}
	}while(valid_input == false);
	remove_order(remove_order_num);

}
void Restaurant::remove_from_menu()
{
	int remove_pizza_num = 0;
	bool valid_input = false;
	do{
		cout << "please choose the pizza you want to remove" << endl;
		view_menu();
		cin >> remove_pizza_num;
		if(remove_pizza_num > menu.get_num_pizzas()|| remove_pizza_num < 0){
			valid_input = false;
		}else{
			valid_input = true;
		}
	}while(valid_input == false);
	menu.remove_pizza(remove_pizza_num);
	view_menu();
	menu.put_pizza_in_file();
}
/*void Restaurant::add_to_menu()
{
	menu.load_pizza();
	
}*/
void Restaurant::customer_menu()
{
	bool customer_prompt = false;
	int customer_option = 0;
	do{
		cout << "1. View Menu" << endl;
		cout << "2. Search by Cost" << endl;
		cout << "3. Search by Ingredients" << endl;
		cout << "4. Place Order" << endl;
		cout << "5. View Hours" << endl;
		cout << "6. View Address" << endl;
		cout << "7. View Phone" << endl;
		cout << "8. Log out" <<endl; 
		cin >> customer_option;
		customer_prompt = customer_option_result(customer_option);
	}while(customer_prompt == false);
}
bool Restaurant::customer_option_result(int customer_option)
{
	bool customer_prompt = false;
	switch(customer_option){
		case 1:view_menu();
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:place_order();
			break;
		case 5:view_hours();
			break;
		case 6:view_address();
			break;
		case 7:view_phone();
			break;
		case 8:customer_prompt = true;
			break;
		default:
			cout << "You did not enter the correct input, " << " ";
			cout << "please try again" << endl;
	}
	return customer_prompt;
}
void Restaurant::view_menu()
{
	menu.print_pizza(menu.get_pizzas());
	cout << endl;
}
void Restaurant::view_hours()
{
	for(int i = 0; i < num_day; i++){
		cout << week[i].day << " ";
		cout << week[i].open_hour << " ";
		cout << week[i].close_hour << endl;
	}
	cout << endl;
}
void Restaurant::load_data()
{
	get_employee();
	get_hours();
	menu_load_pizza();
	get_orders();
}
void Restaurant::view_address()
{
	cout << address << endl;
	cout << endl;
		
}
void Restaurant::view_phone()
{
	cout << phone << endl;
	cout << endl;
}

