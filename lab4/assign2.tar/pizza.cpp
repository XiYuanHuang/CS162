/*********************************************************************
 * ** Program Filename:pizza.cpp
 * ** Author:XiYuan Huang
 * ** Date:10/22/2018
 * ** Description:This file includes all the pizza public function
 * ** Input:N/A
 * ** Output:N/A
 * *********************************************************************/
#include "pizza.h"

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>

using namespace std;

Pizza::Pizza()
{
	name = " ";
	small_cost = 0;		
	medium_cost = 0;
  	large_cost = 0;
	num_ingredients = 0;
 	ingredients = NULL;
			
}
Pizza::~Pizza()
{
	delete [] ingredients;
	ingredients = NULL;	
}
/*********************************************************************
 * ** Function:pizza nondefault constructor
 * ** Description:This function load a line of data from the file.
 * ** Parameters:&file_name
 * ** Pre-Conditions:N/A
 * ** Post-Conditions:N/A
 * *********************************************************************/ 
Pizza::Pizza(ifstream& pizza_file)
{
	pizza_file >> name;
	pizza_file >> small_cost;
	pizza_file >> medium_cost;
	pizza_file >> large_cost; 
	pizza_file >> num_ingredients;
	ingredients = new string[num_ingredients];
	for(int i = 0; i < num_ingredients; i++){
		pizza_file >> ingredients[i];
	}
	
}
Pizza::Pizza(const Pizza &copy)
{
	name = copy.name;
	small_cost = copy.small_cost;
	medium_cost = copy.medium_cost;
	large_cost = copy.large_cost;
	num_ingredients = copy.num_ingredients;
	ingredients = new string[num_ingredients];
	for(int i = 0; i < num_ingredients; i++){
		ingredients[i] = copy.ingredients[i];
	}
}
Pizza& Pizza:: operator = (const Pizza &copy)
{	if(&copy != this){
	name = copy.name;
	small_cost = copy.small_cost;
	medium_cost = copy.medium_cost;
	large_cost = copy.large_cost;
	num_ingredients = copy.num_ingredients;
	if(this -> ingredients != NULL){
		delete [] ingredients;
	}
	ingredients = new string[num_ingredients];
	for(int i = 0; i < num_ingredients; i++){
		ingredients[i] = copy.ingredients[i];
	}
	}
	return *this;

}
/*void Pizza::add_pizza()
{
	cout << "the pizza name:" << " ";cin >> name;
	cout << "the small_cost:" << " ";cin >> small_cost;
	cout << "the medium_cost:" << " ";cin >> medium_cost;
	cout << "the large_cost:" << " ";cin >> large_cost;
	cout << "the num_ingredients" << " ";cin >> num_ingredients;
	cout << "the ingredients" <<" ";
	for(int i = 0; i < num_ingredients; i++){
		 cin >> ingredients[i];
	}
}*/
string Pizza::get_name()
{
	return name;
}
void Pizza::set_name(string newName)
{
	name = newName;
}
int Pizza::get_small_cost()
{
	return small_cost;
}
void Pizza::set_small_cost(int new_small_cost)
{
	small_cost = new_small_cost;
}
int Pizza::get_medium_cost()
{
	return medium_cost;
}
void Pizza::set_medium_cost(int new_medium_cost)
{
	medium_cost = new_medium_cost;
}
int Pizza::get_large_cost()
{
	return large_cost;
}
void Pizza::set_large_cost(int new_large_cost)
{
	large_cost = new_large_cost;
}
int Pizza::get_num_ingredients()
{
	return num_ingredients;
}
void Pizza::set_num_ingredients(int new_num_ingredients)
{
	num_ingredients = new_num_ingredients;
}
string* Pizza::get_ingredients()
{
	return ingredients;
} 
void Pizza::set_ingredients(string* new_ingredients)
{
	for(int i = 0; i < num_ingredients; i++){
		ingredients[i] = new_ingredients[i];
	}
}
