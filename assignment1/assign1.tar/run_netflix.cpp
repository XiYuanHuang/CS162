/***************************************************************************
 * * Program: run_netflix.cpp
 * * Author: XiYuan Huang
 * * Date: 10/7/2018
 * * Description: This program accepts the user's requirement and 
 * 		  outputs the detail of the movies.
 * * Input: The enput is the number from the user which represents their option.
 * * Output: The detail of the movies which depends on the user's option.
 * *************************************************************************/

#include <iostream>
#include <fstream>
#include <cstring>
#include "netflix.h"
#include <cstdlib>

using namespace std;


int main(int argc, char* argv[])
{
	if(argc < 3){

		if(argv[1] == string( "database.txt")){
		
			cout << "You enter: " << argv[1] << endl;
		}else{
			cout << "You did not enter the correct file" << endl;
		}
	}else{
		cout << "the input is not valid" << endl;
	}
	
	ifstream targetfile;
	targetfile.open(argv[1]);
		
	if(targetfile.is_open()){
		cout << "File is open now!" << endl;
		cout << endl;
		
		int num_genre;
		float user_input;
		targetfile >> num_genre;
		genre* genreArray = create_genres(num_genre);		
		get_genre_data(genreArray, num_genre, targetfile);	
		int user_option = 0;
		bool exit_program = false;
		do{
		cout << "1.the genre with the most movies, enter 1" << endl;
		cout << "2.the movie with the highest rating, enter 2" << endl; 
		cout << "3.the average rating for all movies in a genre, enter 3" << endl;
		cout << "4.the genre with an average movie rating above a certain amount, enter 4" << endl;
		cout << "5.the movie with the most actors and who those actors are, enter 5" << endl;
		cout << "6.all movies sorted by rating,enter 6" << endl;
		cout << "7.all movies that are suggested for you, enter 7" << endl;
		cout << "8.exit the program, enter 8" << endl;
		cout << endl;
		cin >> user_option;

		if(user_option == 1){
			most_movie_genre(genreArray, num_genre);
			cout << endl;	
		}else if(user_option == 2){
			highest_rating_movie(genreArray, num_genre);
			cout << endl;
		}else if(user_option == 5){
			most_actors_movie(genreArray, num_genre);
			cout << endl;
		}else if(user_option == 7){
			suggested_movies(genreArray, num_genre);
			cout << endl;
		}else if(user_option == 3){
			average_genre(genreArray, num_genre);
			cout << endl;
		}else if(user_option == 4){
			cout << "Please enter a number, and I will show you the genre with" << " ";  
			cout << "an average movie rating above that number " << endl;
			cout << "The number you want:" << " ";
			cin >> user_input;
			cout << endl;
			genre_above_average(genreArray, num_genre,user_input);
			cout << endl;
		}else if(user_option == 8){
			exit_program = true;
		}else if(user_option == 6){
			movie_sorting(genreArray, num_genre);
			cout << endl;
		}else{
			cout << "you do not enter the correct input" << endl;
		}
		}while(exit_program == false);

		delete_info(&genreArray, num_genre);
	

		/*for(int i = 0; i < num_genre; i++){
			cout << genreArray[i].genre_name << " ";
			cout << genreArray[i].num_movies << endl;
			for(int j = 0; j < genreArray[i].num_movies ; j++){
				cout << genreArray[i].m[j].title << " ";
				cout << genreArray[i].m[j].rating << " ";
				cout << genreArray[i].m[j].num_actors << " ";
				for(int z = 0; z < genreArray[i].m[j].num_actors; z++){
					cout << genreArray[i].m[j].actors[z] << " ";
				}
				if(genreArray[i].m[j].suggested == 1){
					cout << "true" << endl;
					//cout << genreArray[i].m[j].suggested << endl;
				}else{
					cout << "false" << endl;
				}
			} 
		}	*/

	}	

		
	targetfile.close();	
return 0;
}
